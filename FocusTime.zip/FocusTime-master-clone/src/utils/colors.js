export const colors = {
  white: '#fff',
  darkBlue: '#252250',
};
